#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool


class DroneStatusNode(Node):
    def __init__(self):
        super().__init__('status_node')

        self.current_state = "NORMAL"
        self.emergency_shutdown = False

        # ✅ Battery failsafe input
        self.create_subscription(
            String,
            '/failsafe/battery_command',
            self.battery_cb,
            10
        )

        # ✅ Emergency trigger from GUI
        self.create_subscription(
            Bool,
            '/emergency_stop',
            self.emergency_cb,
            10
        )

        # ✅ NEW: Publish status to GUI
        self.status_pub = self.create_publisher(
            String,
            '/drone/status',
            10
        )

        # Timer for periodic status update
        self.create_timer(1.0, self.publish_status)

        self.get_logger().info("Status Node Started")

    # 🔋 Battery-based state
    def battery_cb(self, msg):
        if not self.emergency_shutdown:
            self.current_state = msg.data  # NORMAL / RTH / LAND

    # 🚨 Emergency override
    def emergency_cb(self, msg):
        if msg.data:
            self.emergency_shutdown = True
            self.current_state = "EMERGENCY STOP"
            self.get_logger().error("🚨 EMERGENCY! Motors shutdown!")

    # 📡 Publish to GUI
    def publish_status(self):
        msg = String()
        msg.data = self.current_state
        self.status_pub.publish(msg)

        self.get_logger().info(f"Drone Status: {self.current_state}")


def main(args=None):
    rclpy.init(args=args)
    node = DroneStatusNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()
