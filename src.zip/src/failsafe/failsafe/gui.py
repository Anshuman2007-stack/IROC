import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
import tkinter as tk


class GuiNode(Node):

    def __init__(self):
        super().__init__('gui_node')

        # Publisher
        self.publisher_ = self.create_publisher(Bool, '/emergency_flag', 10)

        # Internal state
        self.emergency_active = False

        self.get_logger().info("GUI Node Started")

    def publish_emergency(self, state: bool):
        msg = Bool()
        msg.data = state

        # Publish multiple times for reliability
        for _ in range(5):
            self.publisher_.publish(msg)

        self.get_logger().info(f"Emergency Flag Sent: {state}")

    def trigger_emergency(self):
        if not self.emergency_active:
            self.emergency_active = True
            self.publish_emergency(True)
            self.status_label.config(text="STATUS: EMERGENCY", fg="red")

    def reset_emergency(self):
        self.emergency_active = False
        self.publish_emergency(False)
        self.status_label.config(text="STATUS: NORMAL", fg="green")


def main(args=None):
    rclpy.init(args=args)

    node = GuiNode()

    # ---------------- GUI ---------------- #
    root = tk.Tk()
    root.title("Failsafe Control Panel")
    root.geometry("300x200")

    # Status Label
    node.status_label = tk.Label(root, text="STATUS: NORMAL", fg="green", font=("Arial", 14))
    node.status_label.pack(pady=20)

    # Emergency Button
    emergency_btn = tk.Button(
        root,
        text="EMERGENCY STOP",
        bg="red",
        fg="white",
        font=("Arial", 12),
        width=20,
        height=2,
        command=node.trigger_emergency
    )
    emergency_btn.pack(pady=10)

    # Reset Button
    reset_btn = tk.Button(
        root,
        text="RESET",
        bg="gray",
        fg="white",
        font=("Arial", 10),
        width=20,
        command=node.reset_emergency
    )
    reset_btn.pack(pady=5)

    # ROS spin integrated with Tkinter loop
    def spin():
        rclpy.spin_once(node, timeout_sec=0.1)
        root.after(100, spin)

    root.after(100, spin)

    # Run GUI
    root.mainloop()

    # Cleanup
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
