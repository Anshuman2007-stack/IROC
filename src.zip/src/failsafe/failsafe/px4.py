#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from px4_msgs.msg import VehicleCommand


class Px4Node(Node):

    def __init__(self):
        super().__init__('px4_node')

        # SAME topic from emergency node
        self.sub = self.create_subscription(
            VehicleCommand,
            '/kill_command',
            self.on_kill_request,
            10
        )

        # PX4 FMU publisher
        self.pub = self.create_publisher(
            VehicleCommand,
            '/fmu/in/vehicle_command',
            10
        )

        self.get_logger().info("PX4 Node started. Waiting for kill commands...")

    def on_kill_request(self, msg: VehicleCommand):
        self.get_logger().error(
            f"🚨 Kill request received! Command: {msg.command}"
        )

        cmd = VehicleCommand()
        cmd.command = VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM
        cmd.param1 = 0.0       # disarm
        cmd.param2 = 21196.0   # FORCE DISARM
        cmd.target_system = 1
        cmd.target_component = 1
        cmd.source_system = 1
        cmd.source_component = 1
        cmd.from_external = True

        for _ in range(5):
            self.pub.publish(cmd)

        self.get_logger().warn("🔥 ESC KILL COMMAND SENT → Motors OFF")


def main(args=None):
    rclpy.init(args=args)
    node = Px4Node()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

if __name__ == '__main__':
    main()
