#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import BatteryState
from std_msgs.msg import String, Float32
import json

class SimpleBatteryFailsafe(Node):
    def __init__(self):
        super().__init__("first_node")

        self.RTH_THRESHOLD = 30.0
        self.LAND_THRESHOLD = 15.0

        self.last_state = None
        self.current_battery = 0.0
        self.current_voltage = 0.0

        # Subscriber
        self.create_subscription(
            BatteryState,
            '/mavros/battery',
            self.battery_cb,
            10
        )

        # Failsafe command publisher
        self.cmd_pub = self.create_publisher(
            String,
            '/failsafe/battery_command',
            10
        )

        # Existing battery percent publisher (keep if needed)
        self.batt_pub = self.create_publisher(
            Float32,
            '/drone/battery_percent',
            10
        )

        # ✅ NEW: GUI telemetry publisher
        self.gui_pub = self.create_publisher(
            String,
            '/drone/telemetry',
            10
        )

        # Timer (prints every second)
        self.create_timer(1.0, self.timer_cb)

    def battery_cb(self, msg):
        self.current_battery = msg.percentage * 100.0
        self.current_voltage = msg.voltage

        # ✅ Publish raw battery %
        batt_msg = Float32()
        batt_msg.data = self.current_battery
        self.batt_pub.publish(batt_msg)

        # 🔥 Determine state
        if self.current_battery <= self.LAND_THRESHOLD:
            state = "LAND"
        elif self.current_battery <= self.RTH_THRESHOLD:
            state = "RTH"
        else:
            state = "NORMAL"

        # ✅ Send failsafe command if state changes
        if state != self.last_state:
            self.get_logger().warn(
                f"Battery: {self.current_battery:.1f}% → {state}"
            )

            cmd_msg = String()
            cmd_msg.data = state
            self.cmd_pub.publish(cmd_msg)

        self.last_state = state

        # ✅ NEW: Send data to GUI
        gui_data = {
            "battPct": round(self.current_battery, 2),
            "battVolts": round(self.current_voltage, 2),
            "battStatus": state
        }

        gui_msg = String()
        gui_msg.data = json.dumps(gui_data)

        self.gui_pub.publish(gui_msg)

    def timer_cb(self):
        self.get_logger().info(
            f"Current Battery: {self.current_battery:.1f}%"
        )


def main(args=None):
    rclpy.init(args=args)
    node = SimpleBatteryFailsafe()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
