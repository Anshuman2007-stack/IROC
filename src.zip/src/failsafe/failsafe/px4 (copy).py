import rclpy
from rclpy.node import Node
from px4_msgs.msg import VehicleCommand

class Px4Node(Node):
    def __init__(self):
        super().__init__('px4_node')

        # Subscribe to the correct topic from emergency.py
        self.sub = self.create_subscription(
            VehicleCommand,
            '/kill_command',  # now matches emergency.py
            self.on_kill_request,
            10
        )

        # Publisher to PX4 FMU
        self.pub = self.create_publisher(
            VehicleCommand,
            '/fmu/in/vehicle_command',
            10
        )

        self.get_logger().info("PX4 Node started. Waiting for kill commands...")

    def on_kill_request(self, msg: VehicleCommand):
        # Log the received kill request
        self.get_logger().warn(f"Kill request received! Command: {msg.command}, param1: {msg.param1}, param2: {msg.param2}")
        
        # Reconstruct the VehicleCommand to ensure correct system/component IDs
        cmd = VehicleCommand()
        cmd.command = VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM
        cmd.param1 = 0.0       # disarm
        cmd.param2 = 21196.0   # force disarm (ESC cut)
        cmd.target_system = 1
        cmd.target_component = 1
        cmd.source_system = 1
        cmd.source_component = 1
        cmd.from_external = True

        # Publish multiple times for reliability
        for _ in range(5):
            self.pub.publish(cmd)

        # Print/log for confirmation
        self.get_logger().info("ESC kill command sent to PX4. Motors should now be cut off!")

def main(args=None):
    rclpy.init(args=args)
    node = Px4Node()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
