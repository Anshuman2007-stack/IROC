import rclpy
from rclpy.node import Node
from std_msgs.msg import String, Bool

class DroneStatusNode(Node):
    def __init__(self):
        super().__init__('status_node')

        self.current_state = "NORMAL"
        self.emergency_shutdown = False

        
        self.create_subscription(
            String,
            '/failsafe/battery_command',
            self.battery_cb,
            10
        )

        
        self.create_subscription(
            Bool,
            '/emergency_stop',
            self.emergency_cb,
            10
        )

       
        self.create_subscription(
            String,
            '/failsafe/emergency',
            self.emergency_node_cb,
            10
        )

        self.create_timer(2.0, self.display_status)

    def battery_cb(self, msg):
        if not self.emergency_shutdown:
            self.current_state = msg.data

    def emergency_cb(self, msg):
        if msg.data:
            self.emergency_shutdown = True
            self.current_state = "MOTORS SHUTDOWN"
            self.get_logger().error("EMERGENCY! All motors shut down!")

    def emergency_node_cb(self, msg):
        
        self.get_logger().error(f"Emergency node says: {msg.data}")

    def display_status(self):
        self.get_logger().info(f"Drone Status: {self.current_state}")

def main(args=None):
    rclpy.init(args=args)
    node = DroneStatusNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
