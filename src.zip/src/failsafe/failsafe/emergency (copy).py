import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
from px4_msgs.msg import VehicleCommand


class EmergencyNode(Node):

    def __init__(self):
        super().__init__('emergency_node')

        # Subscriber from GUI (no change)
        self.sub = self.create_subscription(
            Bool,
            '/emergency_flag',
            self.emergency_callback,
            10
        )

        # Publisher to PX4 Node instead of PX4 directly
        self.pub = self.create_publisher(
            VehicleCommand,
            '/kill_command',  # <-- changed topic
            10
        )

        self.triggered = False
        self.get_logger().info("Emergency Node Started")

    def emergency_callback(self, msg: Bool):
        # Still listening to GUI
        if msg.data and not self.triggered:
            self.get_logger().warn("EMERGENCY TRIGGERED - sending kill request")
            self.triggered = True
            self.send_kill_request()
        elif not msg.data:
            # Allow retrigger if reset
            self.triggered = False

    def send_kill_request(self):
        # Build a VehicleCommand message
        cmd = VehicleCommand()
        cmd.command = VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM
        cmd.param1 = 0.0         # disarm
        cmd.param2 = 21196.0     # FORCE_DISARM
        cmd.target_system = 1
        cmd.target_component = 1
        cmd.source_system = 1
        cmd.source_component = 1
        cmd.from_external = True

        # Publish multiple times for reliability
        for _ in range(5):
            self.pub.publish(cmd)

        self.get_logger().info("Kill request sent to PX4 Node")


def main(args=None):
    rclpy.init(args=args)
    node = EmergencyNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
