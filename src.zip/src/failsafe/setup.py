from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'failsafe'

setup(
    name=package_name,
    version='0.0.0',  #  updated
    packages=find_packages(exclude=['test']),
    data_files=[
        # ROS package index
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),

        # package.xml
        ('share/' + package_name, ['package.xml']),

        #  ADD: templates for Flask
        (os.path.join('share', package_name, 'templates'),
            glob('failsafe/templates/*.html')),

        #  ADD: static files (css/js)
        (os.path.join('share', package_name, 'static'),
            glob('failsafe/static/*')),
    ],
    install_requires=[
        'setuptools',
        'flask',               #  required
        'flask-socketio',      #  required
        'eventlet',            #  required
    ],
    zip_safe=True,
    maintainer='nidar',
    maintainer_email='nidar@todo.todo',
    description='Failsafe system with GUI for drone monitoring',  #  updated
    license='MIT',  #  updated (change if needed)
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'battery_node = failsafe.battery:main',
            'emergency_node = failsafe.emergency:main',
            'comm_node = failsafe.comm:main',
            'vio_node = failsafe.vio:main',
            'status_node = failsafe.status:main',
            'gui_node = failsafe.gui:main',
            'px4_node = failsafe.px4:main',
            

            #  Flask GUI server
            'drone_gui_node = failsafe.server:main',
        ],
    },
)
