from setuptools import find_packages, setup

package_name = 'drone_gui'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/drone_gui.launch.py']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='kaushiki',
    maintainer_email='kaushiki@todo.todo',
    description='Drone GUI package',
    license='TODO: License declaration',
    extras_require={
        'test': ['pytest'],
    },
    entry_points={
        'console_scripts': [
            'telemetry_node  = drone_gui.telemetry_node:main',
            'camera_node     = drone_gui.camera_node:main',
            'mission_bridge  = drone_gui.mission_bridge:main',
            'ros_interface   = drone_gui.ros_interface:main',
        ],
    },
)
