#!/usr/bin/env python3
"""
Camera is handled inside server.py — this node is not needed.
"""
import rclpy

def main(args=None):
    print('[INFO] camera_node: camera is handled inside server.py — no need to run this.')

if __name__ == '__main__':
    main()
