#!/usr/bin/env python3
"""
Mission Bridge Node
Receives high-level mission commands from the web GUI (via the Flask
server publishing on /mission_command) and calls the appropriate
MAVROS services.

Topic consumed:
  /mission_command  (std_msgs/String)
  Supported values: "START", "STOP", "EMERGENCY"

Services called:
  /mavros/cmd/arming   (mavros_msgs/CommandBool)
  /mavros/set_mode     (mavros_msgs/SetMode)
"""

import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from mavros_msgs.srv import CommandBool, SetMode


class MissionBridge(Node):

    def __init__(self):
        super().__init__('mission_bridge')

        # Service clients
        self._arming_client = self.create_client(CommandBool, '/mavros/cmd/arming')
        self._mode_client = self.create_client(SetMode, '/mavros/set_mode')

        # Command subscriber
        self.create_subscription(
            String,
            '/mission_command',
            self._command_cb,
            10,
        )

        self.get_logger().info('MissionBridge started — waiting for /mission_command')

    # ── Command handler ───────────────────────────────────────────────

    def _command_cb(self, msg: String):
        command = msg.data.strip().upper()
        self.get_logger().info(f'Mission command received: {command}')

        if command == 'START':
            self._set_mode('OFFBOARD')

        elif command == 'STOP':
            self._set_mode('AUTO.LOITER')

        elif command == 'EMERGENCY':
            self.get_logger().warn('EMERGENCY STOP — disarming immediately')
            self._arm(False)

        else:
            self.get_logger().warn(f'Unknown command: {command}')

    # ── MAVROS service helpers ────────────────────────────────────────

    def _set_mode(self, mode: str):
        if not self._mode_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error('/mavros/set_mode service not available')
            return
        req = SetMode.Request()
        req.custom_mode = mode
        future = self._mode_client.call_async(req)
        future.add_done_callback(
            lambda f: self.get_logger().info(
                f'SetMode({mode}) result: {f.result().mode_sent}'
                if f.result() else f'SetMode({mode}) failed'
            )
        )

    def _arm(self, value: bool):
        if not self._arming_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().error('/mavros/cmd/arming service not available')
            return
        req = CommandBool.Request()
        req.value = value
        future = self._arming_client.call_async(req)
        future.add_done_callback(
            lambda f: self.get_logger().info(
                f'Arm({value}) result: {f.result().success}'
                if f.result() else f'Arm({value}) failed'
            )
        )


def main(args=None):
    rclpy.init(args=args)
    node = MissionBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()