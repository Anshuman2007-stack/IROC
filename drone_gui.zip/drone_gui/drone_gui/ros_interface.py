#!/usr/bin/env python3
"""
ROS Interface Node
Bridges /drone/telemetry into shared state dict for server.py.
Uses SingleThreadedExecutor so server.py can safely add more
nodes (e.g. CameraSubscriberNode) to separate executors in the
same rclpy context.
"""

import json
import threading

import rclpy
from rclpy.node import Node
from rclpy.executors import SingleThreadedExecutor
from std_msgs.msg import String

state = {
    'battPct': 0.0, 'battVolts': 0.0, 'battStatus': 'Unknown',
    'battUsed': '...', 'battRemStr': '...',
    'pX': 0.0, 'pY': 0.0, 'pZ': 0.0,
    'vX': 0.0, 'vY': 0.0, 'vZ': 0.0,
    'pitch': 0.0, 'roll': 0.0, 'yaw': 0.0,
    'armed': False, 'mode': 'UNKNOWN',
    'airspeed': 0.0, 'groundspeed': 0.0,
    'altitude': 0.0, 'climb': 0.0, 'heading': 0,
    'elapsed': 0.0, 'ftFmt': '00:00:00',
    'camera_frame': None,
}
state_lock = threading.Lock()
_node = None


class ROSInterfaceNode(Node):
    def __init__(self):
        super().__init__('ros_interface')
        self.create_subscription(String, '/drone/telemetry', self._telemetry_cb, 10)
        self.get_logger().info('ROSInterfaceNode started — bridging /drone/telemetry → Flask')

    def _telemetry_cb(self, msg):
        try:
            data = json.loads(msg.data)
            with state_lock:
                state.update(data)
        except Exception as e:
            self.get_logger().warn(f'Telemetry parse error: {e}')


def _spin_thread():
    global _node
    rclpy.init()
    _node = ROSInterfaceNode()
    executor = SingleThreadedExecutor()
    executor.add_node(_node)
    try:
        executor.spin()
    finally:
        executor.shutdown()
        _node.destroy_node()
        rclpy.shutdown()


def start():
    t = threading.Thread(target=_spin_thread, daemon=True)
    t.start()
    return t