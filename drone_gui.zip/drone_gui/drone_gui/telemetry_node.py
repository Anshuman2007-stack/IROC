#!/usr/bin/env python3
"""
Telemetry Node
Subscribes to MAVROS topics and publishes a unified JSON telemetry
message on /drone/telemetry at a fixed rate.

Topics consumed:
  /mavros/local_position/pose          → pose x/y/z + orientation quaternion
  /mavros/local_position/velocity_local → velocity x/y/z
  /mavros/battery                      → battery % and voltage
  /mavros/state                        → armed flag and flight mode
  /mavros/vfr_hud                      → airspeed, altitude, climb, heading

Topic published:
  /drone/telemetry  (std_msgs/String, JSON payload)
"""

import json
import math
import time

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from std_msgs.msg import String
from sensor_msgs.msg import BatteryState, NavSatFix
from geometry_msgs.msg import PoseStamped, TwistStamped
from mavros_msgs.msg import State, VfrHud


class TelemetryNode(Node):

    def __init__(self):
        super().__init__('telemetry_node')

        # ── Internal state ──────────────────────────────────────────
        self._pose = {'x': 0.0, 'y': 0.0, 'z': 0.0}
        self._orientation = {'x': 0.0, 'y': 0.0, 'z': 0.0, 'w': 1.0}
        self._velocity = {'x': 0.0, 'y': 0.0, 'z': 0.0}
        self._battery_pct = 0.0
        self._battery_voltage = 0.0
        self._battery_status = 'Unknown'
        self._armed = False
        self._mode = 'UNKNOWN'
        self._vfr_airspeed = 0.0
        self._vfr_groundspeed = 0.0
        self._vfr_altitude = 0.0
        self._vfr_climb = 0.0
        self._vfr_heading = 0
        self._mission_start_time = None
        self._start_time = time.time()

        # ── Subscribers ─────────────────────────────────────────────
        self.create_subscription(
            PoseStamped, '/mavros/local_position/pose',
            self._pose_cb, qos_profile_sensor_data)

        self.create_subscription(
            TwistStamped, '/mavros/local_position/velocity_local',
            self._velocity_cb, qos_profile_sensor_data)

        self.create_subscription(
            BatteryState, '/mavros/battery',
            self._battery_cb, qos_profile_sensor_data)

        self.create_subscription(
            State, '/mavros/state',
            self._state_cb, 10)

        self.create_subscription(
            VfrHud, '/mavros/vfr_hud',
            self._vfr_cb, 10)

        # ── Publisher ────────────────────────────────────────────────
        self._pub = self.create_publisher(String, '/drone/telemetry', 10)

        # ── Publish timer: 10 Hz ─────────────────────────────────────
        self.create_timer(0.1, self._publish)

        self.get_logger().info('TelemetryNode started → publishing on /drone/telemetry')

    # ── Callbacks ────────────────────────────────────────────────────

    def _pose_cb(self, msg):
        p = msg.pose.position
        o = msg.pose.orientation
        self._pose = {'x': round(p.x, 3), 'y': round(p.y, 3), 'z': round(p.z, 3)}
        self._orientation = {'x': o.x, 'y': o.y, 'z': o.z, 'w': o.w}

    def _velocity_cb(self, msg):
        v = msg.twist.linear
        self._velocity = {
            'x': round(v.x, 3),
            'y': round(v.y, 3),
            'z': round(v.z, 3),
        }

    def _battery_cb(self, msg):
        self._battery_pct = round(msg.percentage * 100, 1)
        self._battery_voltage = round(msg.voltage, 2)
        if msg.voltage > 15.5:
            self._battery_status = 'Good'
        elif msg.voltage > 14.0:
            self._battery_status = 'Low'
        else:
            self._battery_status = 'Critical'

    def _state_cb(self, msg):
        self._armed = msg.armed
        self._mode = msg.mode
        if msg.armed and self._mission_start_time is None:
            self._mission_start_time = time.time()
        if not msg.armed:
            self._mission_start_time = None

    def _vfr_cb(self, msg):
        self._vfr_airspeed = round(msg.airspeed, 2)
        self._vfr_groundspeed = round(msg.groundspeed, 2)
        self._vfr_altitude = round(msg.altitude, 2)
        self._vfr_climb = round(msg.climb, 2)
        self._vfr_heading = msg.heading

    # ── Helpers ───────────────────────────────────────────────────────

    def _quaternion_to_euler(self):
        q = self._orientation
        sinr = 2 * (q['w'] * q['x'] + q['y'] * q['z'])
        cosr = 1 - 2 * (q['x'] ** 2 + q['y'] ** 2)
        roll = math.degrees(math.atan2(sinr, cosr))

        sinp = 2 * (q['w'] * q['y'] - q['z'] * q['x'])
        pitch = math.degrees(math.asin(max(-1.0, min(1.0, sinp))))

        siny = 2 * (q['w'] * q['z'] + q['x'] * q['y'])
        cosy = 1 - 2 * (q['y'] ** 2 + q['z'] ** 2)
        yaw = math.degrees(math.atan2(siny, cosy))

        return round(pitch, 1), round(roll, 1), round(yaw, 1)

    # ── Publish ───────────────────────────────────────────────────────

    def _publish(self):
        ft = 0.0
        if self._mission_start_time:
            ft = time.time() - self._mission_start_time
        h = int(ft // 3600)
        m = int((ft % 3600) // 60)
        s = int(ft % 60)

        # Estimate remaining battery time (simple linear model)
        max_flight_time = 1200  # 20 min
        max_capacity_mah = 5200
        elapsed_total = time.time() - self._start_time
        pct_used = max(0.0, 87.0 - self._battery_pct)
        consumed_mah = int((pct_used / 100.0) * max_capacity_mah)
        remaining_sec = max(0, max_flight_time - elapsed_total)
        rem_m = int(remaining_sec // 60)
        rem_s = int(remaining_sec % 60)

        pitch, roll, yaw = self._quaternion_to_euler()

        payload = {
            # Battery
            'battPct':    self._battery_pct,
            'battVolts':  self._battery_voltage,
            'battStatus': self._battery_status,
            'battUsed':   f'{consumed_mah} mAh',
            'battRemStr': f'{rem_m}m {rem_s:02d}s',
            # Pose
            'pX': self._pose['x'],
            'pY': self._pose['y'],
            'pZ': self._pose['z'],
            # Velocity
            'vX': self._velocity['x'],
            'vY': self._velocity['y'],
            'vZ': self._velocity['z'],
            # IMU (euler from quaternion)
            'pitch': pitch,
            'roll':  roll,
            'yaw':   yaw,
            # Flight state
            'armed':   self._armed,
            'mode':    self._mode,
            # VFR
            'airspeed':   self._vfr_airspeed,
            'groundspeed': self._vfr_groundspeed,
            'altitude':   self._vfr_altitude,
            'climb':      self._vfr_climb,
            'heading':    self._vfr_heading,
            # Time
            'elapsed': round(ft, 1),
            'ftFmt':   f'{h:02d}:{m:02d}:{s:02d}',
        }

        msg = String()
        msg.data = json.dumps(payload)
        self._pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = TelemetryNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()