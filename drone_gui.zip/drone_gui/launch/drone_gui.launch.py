from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(package='drone_gui', executable='telemetry_node',  name='telemetry_node'),
        Node(package='drone_gui', executable='camera_node',     name='camera_node'),
        Node(package='drone_gui', executable='mission_bridge',  name='mission_bridge'),
    ])
