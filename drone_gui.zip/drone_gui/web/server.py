#!/usr/bin/env python3
import os
import sys
import json
import threading
import time
import math
from flask import Flask, render_template, request, jsonify, Response
from flask_socketio import SocketIO, emit
import queue

app = Flask(__name__)
app.config['SECRET_KEY'] = 'drone_gui_secret'
app.config['UPLOAD_FOLDER'] = os.path.join(os.path.dirname(__file__), 'uploads')
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# ── Make drone_gui package importable ────────────────────────────────
_pkg_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if _pkg_dir not in sys.path:
    sys.path.insert(0, _pkg_dir)

# ── ROS2 ─────────────────────────────────────────────────────────────
ROS2_AVAILABLE = False
ros_node = None

try:
    import rclpy
    from rclpy.node import Node
    from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy, HistoryPolicy, qos_profile_sensor_data
    from rclpy.executors import SingleThreadedExecutor
    from sensor_msgs.msg import Image
    from std_msgs.msg import String
    import cv2
    from cv_bridge import CvBridge
    ROS2_AVAILABLE = True
    print("[INFO] ROS2 available")
except ImportError as e:
    print(f"[WARN] ROS2 not available ({e}) — demo mode")

# ── MJPEG per-client queues ───────────────────────────────────────────
_mjpeg_clients = []
_mjpeg_clients_lock = threading.Lock()

def _mjpeg_push_frame(jpeg_bytes):
    with _mjpeg_clients_lock:
        for q in _mjpeg_clients:
            if not q.empty():
                try: q.get_nowait()
                except queue.Empty: pass
            q.put(jpeg_bytes)

# ── Shared telemetry state (written by ROS, read by broadcast) ────────
telemetry_state = {}
telemetry_lock = threading.Lock()

# ── ROS2 nodes ────────────────────────────────────────────────────────
if ROS2_AVAILABLE:
    _CAM_QOS = QoSProfile(
        reliability=ReliabilityPolicy.RELIABLE,
        durability=DurabilityPolicy.TRANSIENT_LOCAL,
        history=HistoryPolicy.KEEP_LAST,
        depth=10,
    )

    class DroneGUINode(Node):
        def __init__(self):
            super().__init__('drone_gui_node')
            self._bridge = CvBridge()
            self._jpeg_quality = 60

            # Telemetry from telemetry_node
            self.create_subscription(
                String, '/drone/telemetry',
                self._telemetry_cb, 10)

            # Camera direct from RealSense
            self.create_subscription(
                Image, '/camera/camera/color/image_raw',
                self._camera_cb, _CAM_QOS)

            self.get_logger().info('DroneGUINode started — /drone/telemetry + /camera/camera/color/image_raw')

        def _telemetry_cb(self, msg):
            try:
                data = json.loads(msg.data)
                with telemetry_lock:
                    telemetry_state.update(data)
            except Exception as e:
                self.get_logger().warn(f'Telemetry parse error: {e}')

        def _camera_cb(self, msg):
            try:
                frame = self._bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
                ret, buf = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, self._jpeg_quality])
                if ret:
                    _mjpeg_push_frame(buf.tobytes())
            except Exception as e:
                self.get_logger().warn(f'Camera CB error: {e}')

    def ros2_spin_thread():
        global ros_node
        rclpy.init()
        ros_node = DroneGUINode()
        executor = SingleThreadedExecutor()
        executor.add_node(ros_node)
        try:
            executor.spin()
        finally:
            executor.shutdown()
            ros_node.destroy_node()
            rclpy.shutdown()

# ── Demo mode ─────────────────────────────────────────────────────────
def demo_data_thread():
    t = 0.0
    start = time.time()
    while True:
        t += 0.1
        elapsed = time.time() - start
        h = int(elapsed // 3600); m = int((elapsed % 3600) // 60); s = int(elapsed % 60)
        spd = abs(2 + math.sin(t * 0.3))
        with telemetry_lock:
            telemetry_state.update({
                'battPct':    round(95 - elapsed * 0.02, 1),
                'battVolts':  round(11.8, 2),
                'battStatus': 'Good',
                'battUsed':   f'{int(elapsed * 0.5)} mAh',
                'battRemStr': f'{max(0,int((1200-elapsed)//60))}m {int((1200-elapsed)%60):02d}s',
                'pX': round(10*math.sin(t*0.12), 3),
                'pY': round(10*math.cos(t*0.12), 3),
                'pZ': round(5+math.sin(t*0.25)*1.5, 3),
                'vX': round(math.cos(t*0.12)*spd, 3),
                'vY': round(-math.sin(t*0.12)*spd, 3),
                'vZ': round(math.sin(t*0.5)*0.3, 3),
                'pitch': round(math.sin(t*0.5)*15, 1),
                'roll':  round(math.cos(t*0.3)*10, 1),
                'yaw':   round((t*10)%360, 1),
                'armed': True, 'mode': 'AUTO.MISSION',
                'elapsed': round(elapsed, 1),
                'ftFmt': f'{h:02d}:{m:02d}:{s:02d}',
                'ping': 35,
            })
        time.sleep(0.1)

# ── Broadcast thread ──────────────────────────────────────────────────
def broadcast_thread():
    while True:
        with telemetry_lock:
            data = dict(telemetry_state)
        data['ping'] = int(30 + (time.time() % 1) * 20)
        socketio.emit('telemetry_update', data)
        time.sleep(0.1)

# ── MJPEG generator ───────────────────────────────────────────────────
def _mjpeg_generator():
    import numpy as np
    img = np.zeros((240, 320, 3), dtype='uint8')
    cv2.putText(img, 'NO CAMERA SIGNAL', (30, 120),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 196, 180), 2)
    _, buf = cv2.imencode('.jpg', img)
    no_signal = buf.tobytes()

    client_q = queue.Queue(maxsize=1)
    with _mjpeg_clients_lock:
        _mjpeg_clients.append(client_q)
    try:
        while True:
            try:
                frame = client_q.get(timeout=2.0)
            except queue.Empty:
                frame = no_signal
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    finally:
        with _mjpeg_clients_lock:
            _mjpeg_clients.remove(client_q)

# ── Flask routes ──────────────────────────────────────────────────────
@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/monitoring.html')
def monitoring():
    return render_template('monitoring.html')

@app.route('/seed.html')
def seed():
    imgs = [f for f in os.listdir(app.config['UPLOAD_FOLDER'])
            if f.lower().endswith(('.png','.jpg','.jpeg'))]
    return render_template('seed.html', seed_images=imgs)

@app.route('/analysis.html')
def analysis():
    return render_template('analysis.html')

@app.route('/video_feed')
def video_feed():
    return Response(_mjpeg_generator(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/state')
def api_state():
    with telemetry_lock:
        return jsonify(dict(telemetry_state))

@app.route('/api/upload_seed', methods=['POST'])
def upload_seed():
    if 'file' not in request.files:
        return jsonify({'error': 'No file'}), 400
    saved = []
    for f in request.files.getlist('file'):
        if f.filename:
            f.save(os.path.join(app.config['UPLOAD_FOLDER'], f.filename))
            saved.append(f.filename)
    return jsonify({'saved': saved})

@app.route('/api/mission/<action>', methods=['POST'])
def mission_action(action):
    print(f"[MISSION] Action: {action}")
    _publish_mission_cmd(action.upper())
    if action == 'start':
        return jsonify({'status': 'Mission started'})
    elif action == 'stop':
        return jsonify({'status': 'Mission stopped'})
    elif action == 'emergency':
        return jsonify({'status': 'EMERGENCY STOP TRIGGERED'})
    return jsonify({'error': 'Unknown action'}), 400

@app.route('/api/set_area', methods=['POST'])
def set_area():
    return jsonify({'status': 'ok'})

# ── SocketIO events ───────────────────────────────────────────────────
@socketio.on('connect')
def on_connect():
    print(f"[WS] Client connected: {request.sid}")
    with telemetry_lock:
        emit('telemetry_update', dict(telemetry_state))

@socketio.on('disconnect')
def on_disconnect():
    print(f"[WS] Client disconnected: {request.sid}")

@socketio.on('mission_cmd')
def on_mission_cmd(data):
    action = data.get('action', '').upper()
    print(f"[CMD] Mission command: {action}")
    _publish_mission_cmd(action)
    if action == 'EMERGENCY':
        socketio.emit('alert', {'msg': 'EMERGENCY STOP TRIGGERED', 'level': 'critical'})

# ── Mission publisher ─────────────────────────────────────────────────
_mission_pub_node = None

def _publish_mission_cmd(action: str):
    global _mission_pub_node
    if not ROS2_AVAILABLE:
        print(f'[MISSION] (demo) {action}')
        return
    try:
        if _mission_pub_node is None:
            class _Pub(Node):
                def __init__(self):
                    super().__init__('server_mission_pub')
                    self.pub = self.create_publisher(String, '/mission_command', 10)
            _mission_pub_node = _Pub()
        msg = String()
        msg.data = action
        _mission_pub_node.pub.publish(msg)
    except Exception as e:
        print(f'[WARN] Mission publish error: {e}')

# ── Startup ───────────────────────────────────────────────────────────
if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    if ROS2_AVAILABLE:
        ros_thread = threading.Thread(target=ros2_spin_thread, daemon=True)
        ros_thread.start()
        print("[INFO] ROS2 spin thread started")
    else:
        threading.Thread(target=demo_data_thread, daemon=True).start()
        print("[INFO] Demo data thread started")

    threading.Thread(target=broadcast_thread, daemon=True).start()

    print("[INFO] Starting Flask server on http://0.0.0.0:5000")
    socketio.run(app, host='0.0.0.0', port=5000, debug=False)