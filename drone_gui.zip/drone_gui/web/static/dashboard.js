/**
 * dashboard.js — Shared across all pages
 * Initialises the Socket.IO connection and provides helper utilities.
 */

// Global socket (pages attach their own listeners)
const socket = io({ transports: ['websocket', 'polling'] });

socket.on('connect', () => {
  console.log('[GCS] WebSocket connected:', socket.id);
});
socket.on('disconnect', () => {
  console.warn('[GCS] WebSocket disconnected');
});
socket.on('alert', data => {
  showAlert(data.msg, data.level || 'info');
});

/**
 * showAlert(message, level)
 * level: 'info' | 'critical'
 * Auto-hides after 3 seconds.
 */
function showAlert(msg, level = 'info') {
  const el = document.getElementById('globalAlert');
  if (!el) return;
  el.textContent = msg;
  el.className = 'global-alert ' + level;
  clearTimeout(el._timeout);
  el._timeout = setTimeout(() => {
    el.className = 'global-alert hidden';
  }, level === 'critical' ? 5000 : 3000);
}
